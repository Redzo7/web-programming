const sponsors = {
    "Microsoft": 3000,
    "Disney": 3500,
    "Google": 2000,
    "BMW": 1500,
    "K&H": 1750,
    "Ariel": 500,
    "Opel": 2200,
    "Acer": 1250,
    "Tesla": 4500
}
const spaceships = [
    {
        name: 'Hófehérke',
        sponsors: ["Microsoft", "Disney"],
        seconds_to_orbit: 319
    },
    {
        name: 'Hamupipőke',
        sponsors: ["Google", "BMW"],
        seconds_to_orbit: 340
    },
    {
        name: 'Merida',
        sponsors: ["Disney", "BMW", "K&H"],
        seconds_to_orbit: 148
    },
    {
        name: 'Ariel',
        sponsors: ["Ariel"],
        seconds_to_orbit: 367
    },
    {
        name: 'Belle',
        sponsors: ["Opel", "Google", "Disney"],
        seconds_to_orbit: 198
    },
    {
        name: 'Jasmine',
        sponsors: ["BMW", "Acer", "Microsoft"],
        seconds_to_orbit: 386
    },
    {
        name: 'Pocahontas',
        sponsors: ["Ariel", "Disney", "Tesla", "Microsoft"],
        seconds_to_orbit: 302
    },
    {
        name: 'Mulan',
        sponsors: [],
        seconds_to_orbit: 359
    },
    {
        name: 'Rapunzel',
        sponsors: ["Acer", "Microsoft", "Google", "BMW", "Tesla"],
        seconds_to_orbit: 196
    },
    {
        name: 'Elsa',
        sponsors: ["Disney"],
        seconds_to_orbit: 257
    },
    {
        name: 'Anna',
        sponsors: ["Microsoft", "Tesla", "Disney"],
        seconds_to_orbit: 201
    }
]

function delegate(parent, child, when, what) {
    function eventHandlerFunction(event) {
      let eventTarget = event.target;
      let eventHandler = this;
      let closestChild = eventTarget.closest(child);
  
      if (eventHandler.contains(closestChild)) {
        what(event, closestChild);
      }
    }
  
    parent.addEventListener(when, eventHandlerFunction);
}